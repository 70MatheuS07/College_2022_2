#ifndef VETORFREQ_H
#define VETORFREQ_H

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void ZeraVetorFreq(int V[], int tam);

void PreencheVetorFreq(int V[], int tam, char *nomeArq);

void ImprimeVetorFreq(int V[], int tam);

#endif