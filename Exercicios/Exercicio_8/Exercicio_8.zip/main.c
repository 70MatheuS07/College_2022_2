#include <stdlib.h>
#include <stdio.h>
#include "fila.h"
#include "lista.h"

int main()
{
    int comando=0;
    char lixo;

    tFila *fila = CriaFila(8);

    return 0;
}