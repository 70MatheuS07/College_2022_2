#ifndef LERLINHA_H
#define LERLINHA_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char *LerLinha();

#endif
