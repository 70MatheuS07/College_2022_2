#ifndef PEDIDO_H
#define PEDIDO_H

#include <stdlib.h>
#include <stdio.h>
#include "lista.h"
#include "fila.h"

typedef struct Pedido tPedido;

tPedido **CriaPedido(int tam);

#endif