Exercício 2:

Só utilizar o makefile para compilar o arquivo e testar.