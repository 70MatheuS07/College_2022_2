#ifndef LERLINHA_H
#define LERLINHA_H

#include <stdlib.h>
#include <stdio.h>

char *LerLinha();

#endif
