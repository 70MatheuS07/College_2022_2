Foi colocado 3 testes:
test_1: para testar uma lista de produto unico.
test_2: testar as extremidades inicio e fim.
test_3: testar a retirada de um produto no meio da lista.