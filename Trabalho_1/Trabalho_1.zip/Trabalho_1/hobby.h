#ifndef HOBBY_H
#define HOBBY_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "listaHobby.h"

typedef struct Hobby tHobby;

char *ColetaHobbyArquivo(FILE *arquivo);

#endif